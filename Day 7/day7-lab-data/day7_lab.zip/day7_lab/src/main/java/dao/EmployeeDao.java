package dao;

import pojos.Employee;

public interface EmployeeDao {
//add a method to insert new emp details
	String insertEmployeeDetails(Employee emp);
}
