package dao;

import pojos.Employee;
import static utils.HibernateUtils.getFactory;
import org.hibernate.*;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public String insertEmployeeDetails(Employee emp) {
		String mesg="Adding emp details failed!!!!!";
		// get session from Session Factory
		Session session = getFactory().openSession();// takes out a 
		//conn from the DBCP , wraps it in sesison obj n rets it to the caller
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.save(emp);
			tx.commit();
			mesg="Added emp details with ID=" +emp.getEmpId();
		} catch (RuntimeException e) {
			//rollback tx
			if(tx != null)
				tx.rollback();
			//re throw the same exc to the caller : to inform the user
			throw e;
		} finally {
			// session closing
			if (session != null)
				session.close();//pooled out db cn simply rets to the pool!
		}
		return mesg;
	}

}
