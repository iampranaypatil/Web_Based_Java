Dear All, 
Please import both of these projects as existing Maven projects , in your workspace . It will download all spring security related JARs.